/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hotelero;

/**
 *
 * @author ivang
 */
public class Hotelfontaine extends Hoteles{
    //Atributos ocultos
    //Constructores
    public Hotelfontaine(){
        nombre="Hotel Fontaine";
        precio=5000000;
        comprado=false;

    }
    //Metodos¿?
    
}
