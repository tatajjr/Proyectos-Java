/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hotelero;

/**
 *
 * @author ivang
 */
public class Hotelboom extends Hoteles{
    //Atributos ocultos
    //Constructores
    public Hotelboom(){
        nombre="Hotel Boom";
        precio=1100000;
        comprado=false;
        
    }
    //Metodos¿?
    
}
