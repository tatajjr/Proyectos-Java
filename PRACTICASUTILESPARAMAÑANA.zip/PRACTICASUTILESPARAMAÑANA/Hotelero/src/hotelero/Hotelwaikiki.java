/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hotelero;

/**
 *
 * @author ivang
 */
public class Hotelwaikiki extends Hoteles{
    //Atributos ocultos
    //Cosntructores
    public Hotelwaikiki(){
        nombre="Hotel Waikiki";
        precio=4000000;
        comprado=false;

    }
    //Metodos¿?
    
}
