/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hotelero;

/**
 *
 * @author ivang
 */
public class Hotelpresident extends Hoteles{
    //Atributos ocultos
    //Constructores
    public Hotelpresident(){
        nombre="Hotel President";
        precio=3000000;
        comprado=false;

    }
    //Metodos¿?
    
}
