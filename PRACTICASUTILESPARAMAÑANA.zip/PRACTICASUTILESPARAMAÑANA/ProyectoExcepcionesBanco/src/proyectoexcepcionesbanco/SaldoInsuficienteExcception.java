package proyectoexcepcionesbanco;


public class SaldoInsuficienteExcception extends Exception{
    public SaldoInsuficienteExcception(String s){
        super(s);
    }
  
}
