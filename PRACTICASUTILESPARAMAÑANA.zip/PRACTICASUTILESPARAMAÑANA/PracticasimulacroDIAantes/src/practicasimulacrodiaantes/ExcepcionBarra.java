package practicasimulacrodiaantes;

public class ExcepcionBarra extends Exception{
    public ExcepcionBarra(String s){
        super(s);
    }
    
}
